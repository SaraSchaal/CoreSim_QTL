### This set of files has no associated seed because of a coding error. A random seed was still produced and the run did not use the seed supplied at the command line. Can not reproduce these results ###

noSeed_movieData.txt - this is a file where I merged the inversion through time file (noSeed_outputInvTime.txt) with the summary data file about each inversion (noSeed_outputInvSumInfo.txt)
