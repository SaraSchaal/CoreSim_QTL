### This set of files are run with the seed in the file name and can be reproduced. ###

3384725_movieInvData.txt - this is a file where I merged the inversion through time file (3384725_outputInvTime.txt) with the summary data file about each inversion (3384725_outputInvSumInfo.txt) and the parameters for that simulation by merging using the seed (invSimParams.txt)